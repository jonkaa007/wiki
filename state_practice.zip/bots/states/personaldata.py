from aiogram.dispatcher.filters.state import StatesGroup, State

class PersonalData(StatesGroup):
    fullname = State()
    address = State()
    phoneNum = State()
    email = State()
    age = State()