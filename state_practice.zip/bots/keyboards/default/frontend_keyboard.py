from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

frontend_menu = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="HTML"),
            KeyboardButton(text="CSS"),
            KeyboardButton(text="JavaScript")
        ],
        [
            KeyboardButton(text="Arqaga"),
            KeyboardButton(text="Basina")
        ]
    ]
)