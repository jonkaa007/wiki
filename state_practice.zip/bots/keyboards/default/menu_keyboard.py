from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

menu = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton("FrontEnd"),
            KeyboardButton("BackEnd")
        ]
    ],
    resize_keyboard=False
)