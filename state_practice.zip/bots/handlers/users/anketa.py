from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Command

from loader import dp
from states.personaldata import PersonalData
from data.config import ADMINS

@dp.message_handler(Command('register'))
async def anketa(message: types.Message, state: FSMContext):
    await message.answer("Toliq atinizdi kirgizin")
    await PersonalData.fullname.set()
 
@dp.message_handler(state=PersonalData.fullname)
async def answer_fullname(message: types.Message, state: FSMContext):
    await state.update_data(
        {'fullname': message.text}
    )
    
    await message.answer("Address kiritin")
    await PersonalData.next()
    
@dp.message_handler(state=PersonalData.address)
async def answer_address(message: types.Message, state: FSMContext):
    await state.update_data(
        {'address':message.text}
    )
    
    await message.answer("Telefon nomer kiritin")
    await PersonalData.phoneNum.set()
    
@dp.message_handler(state=PersonalData.phoneNum)
async def answer_phonenum(message: types.Message, state: FSMContext):
    await state.update_data(
        {'phone':message.text}
    )
    
    await message.answer("Elektron pochta kirtin")
    await PersonalData.next()

@dp.message_handler(state=PersonalData.email)
async def answer_phonenum(message: types.Message, state: FSMContext):
    await state.update_data(
        {'email':message.text}
    )
    
    await message.answer("Jasinizdi kirtin")
    await PersonalData.next()
    
@dp.message_handler(state=PersonalData.age)
async def answer_phonenum(message: types.Message, state: FSMContext):
    await state.update_data(
        {'age':message.text}
    )
    
    await message.answer("Qabillandi!")
    
    data = await state.get_data()
    fullname = data.get('fullname')
    address = data.get('address')
    phone = data.get('phone')
    email = data.get('email')
    age = data.get('age')
    
    msg = "Bizde taza paydalaniwshi bar: \n"
    msg += f"Fullname: {fullname}\n"
    msg += f"Address: {address}\n"
    msg += f"Phone: {phone}\n"
    msg += f"Email: {email}\n"
    msg += f"Age: {age}"
    
    for admin in ADMINS:
        await dp.bot.send_message(chat_id=admin, text=msg)
    
    await state.finish()