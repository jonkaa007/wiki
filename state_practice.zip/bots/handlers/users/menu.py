from aiogram.dispatcher.filters import Command, Text
from aiogram.types import Message, ReplyKeyboardRemove

from keyboards.default.menu_keyboard import menu
from loader import dp

@dp.message_handler(Command('menu'))
async def menu_cmd(message: Message):
    await message.answer("Kurslardi tanlan", reply_markup=menu)
    
@dp.message_handler(text='FrontEnd')
async def send_info(message: Message):
    await message.answer("FrontEnd kursi 10 ay dawam etedi, ayinda 400 000 sum")

@dp.message_handler(text='BackEnd')
async def send_info(message: Message):
    await message.answer("BackEnd kursi 12 ay dawam etedi, ayina 480 000 sum")
